

#-------------------------------------------------------------------------------
# 1: Tendencia general de delitos
#-------------------------------------------------------------------------------

# Cantidad de delitos agrupados por año (Gráfico Interactivo) 

p <- ggplot(delitos_por_anio, aes(x = año, y = total_delitos)) +
  geom_line(color = "darkblue", linewidth = 1.2)+
  geom_point(color = "black", linewidth = 3) +
  scale_y_continuous(labels = scales::comma,
                     breaks = seq(80000, 160000, by = 10000),
                     limits = c(80000, 160000)) +
  scale_x_continuous(breaks = delitos_por_anio$año) +
  labs(title = "Cantidad de delitos por año",
       x = "Año",
       y = "Delitos totales") +
  theme_minimal()

# Convertimos el gráfico a uno interactivo (plotly) con tooltips

interactive_plot <- ggplotly(p, tooltip = c("x", "y"))

# Mostrar gráfico

interactive_plot

saveWidget(interactive_plot, file = "output/interactive_plot.html",
          selfcontained = TRUE)

#-------------------------------------------------------------------------------
# 2: Delitos más frecuentes con los correspondientes subtipos
#-------------------------------------------------------------------------------

# Graficamos Top 5 tipos más comunes (sin incluir Homicidios)

grafico_top_subtipos <- top_subtipos %>%
  group_by(tipo) %>%
  mutate(
    porcentaje = n / sum(n) * 100,
    etiqueta = paste0(round(porcentaje, 1), "%")
  ) %>%
  ggplot(aes(x = reorder(tipo, n, sum), y = n, fill = subtipo)) +
  geom_col() +
  scale_fill_manual(values = c(
    "Robo total" = "#FF0000",
    "Robo automotor" = "#F2FF20", 
    "Hurto total" = "#F1A208",
    "Hurto automotor" ="#00FFFF",
    "Lesiones Dolosas" = "#00FF00",
    "Lesiones por siniestros viales" = "#FF00FF",
    "Amenazas" = "#AAAAAA",
    "Muertes por siniestros viales" = "#000000"
  )) +
  scale_y_continuous(labels = scales::comma, 
                     breaks = seq(0, 300000, by =30000)) +
  labs(
    title = "Delitos más Comunes",
    subtitle = "CABA 2019-2023 - Incluye tipos y subtipos de delitos más comunes",
    x = "Tipo de delito",
    y = "Cantidad",
    fill = "Subtipo"
  ) +
  theme_minimal()

print(grafico_top_subtipos)
ggsave(file.path(outstub, "grafico_top_subtipos.png"), grafico_top_subtipos, 
       width = 12, height = 8, dpi = 300)
ggsave("output/grafico_top_subtipos.png",
       plot = grafico_top_subtipos, width = 9, height = 6)

# Graficamos solo los homicidios y subtipos

grafico_homicidios <- ggplot(homicidios, aes(x = reorder(subtipo, n),
                                             y = n, fill = subtipo)) +
  geom_col(show.legend = FALSE) +
  geom_text(aes(label = scales::comma(n)), vjust = -0.3, size = 3) +
  scale_color_viridis_d(option = "C", aesthetics = "colour") +
  labs(
    title = "Distribución de Homicidios",
    subtitle = "CABA 2019–2023",
    x = "Tipo de homicidio",
    y = "Cantidad"
  ) +
  scale_y_continuous(labels = scales::comma) +
  theme_minimal()

print(grafico_homicidios)
ggsave(file.path(outstub, "grafico_homicidios.png"), grafico_homicidios, 
       width = 12, height = 8, dpi = 300)
ggsave("output/grafico_homicidios.png",
       plot = grafico_homicidios, width = 9, height = 6)

#-------------------------------------------------------------------------------
# 3: ¿Donde ocurren los delitos?
#-------------------------------------------------------------------------------

# Gráfico de barras horizontal - Top barrios con delito principal

p1 <- ggplot(top_barrios, aes(x = reorder(barrio, n), y = n)) +
  geom_col(fill = "darkred", alpha = 0.8) +
  geom_text(aes(label = etiqueta_completa), 
            hjust = -0.05, size = 2.8, lineheight = 0.9) +
  coord_flip() +
  labs(
    title = "Top 5 Barrios con Mayor Cantidad de Delitos",
    subtitle = "CABA 2019-2023 - Incluye delito más común por barrio",
    x = "Barrio",
    y = "Cantidad de delitos",
    caption = "Porcentajes calculados sobre el total de delitos con barrio identificado"
  ) +
  scale_y_continuous(labels = scales::comma, expand = expansion(mult = c(0, 0.25))) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5))

print(p1)
ggsave(file.path(outstub, "top_barrios_delitos.png"), p1, 
       width = 12, height = 8, dpi = 300)
ggsave("output/top_barrios_delitos.png",
       plot = p1, width = 9, height = 6)

# Gráfico de barras horizontal - Bottom 5 barrios con delito principal

p1b <- ggplot(bottom_barrios, aes(x = reorder(barrio, n), y = n)) +
  geom_col(fill = "darkgreen", alpha = 0.8) +
  geom_text(aes(label = etiqueta_completa), 
            hjust = -0.05, size = 3, lineheight = 0.9) +
  coord_flip() +
  labs(
    title = "Top 5 Barrios con Menor Cantidad de Delitos",
    subtitle = "CABA 2019-2023 - Incluye delito más común por barrio",
    x = "Barrio",
    y = "Cantidad de delitos",
    caption = "Porcentajes calculados sobre el total de delitos con barrio identificado"
  ) +
  scale_y_continuous(labels = scales::comma, expand = expansion(mult = c(0, 0.3))) +
  theme_minimal() +
  theme(plot.title = element_text(hjust = 0.5),
        plot.subtitle = element_text(hjust = 0.5))

print(p1b)

ggsave(file.path(outstub, "bottom_barrios_delitos.png"), p1b, 
       width = 12, height = 6, dpi = 300)
ggsave("output/bottom_barrios_delitos.png",
       plot = p1b, width = 9, height = 6)

#------------------------------------------------------------------------------
# 4: Frecuencia de delitos (delitos por hora y conclusiones)
#------------------------------------------------------------------------------

# Graficamos cantidad de delitos por hora para cada año

grafico_frecuencia_anual <- ggplot(frecuencia_anual, 
                                   aes(x = factor(año), y = delitos_por_hora)) +
  geom_col(show.legend = TRUE, fill = "blue" ) +
  geom_text(aes(label = round(delitos_por_hora, 2)), vjust = -0.5) +
  labs(
    title = "Cantidad promedio de delitos en 1 hora por año",
    subtitle = "CABA 2019-2023",
    x = "Año",
    y = "Cantidad promedio de hechos delictivos en 1 hora",
    caption = "Frecuencia promedio de delitos por hora en cada año"
  ) +
  theme_minimal()

print(grafico_frecuencia_anual)
ggsave(file.path(outstub, "grafico_frecuencia_anual.png"),
       grafico_frecuencia_anual, width = 12, height = 8, dpi = 300)
ggsave("output/grafico_frecuencia_anual.png",
       plot = grafico_frecuencia_anual, width = 9, height = 6)
