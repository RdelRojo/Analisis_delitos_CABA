#-------------------------------------------------------------------------------
# 3. LIMPIEZA Y TRANSFORMACIÓN DE DATOS
#-------------------------------------------------------------------------------

# Resumen inicial

cat("=== RESUMEN INICIAL DEL DATASET ===\n")
cat("Dimensiones:", dim(delitos_completo), "\n")
cat("Columnas:", colnames(delitos_completo), "\n\n")
str(delitos_completo)
summary(delitos_completo)
cat("=== VALORES FALTANTES ===\n")
sapply(delitos_completo, function(x) sum(is.na(x)))
# LIMPIEZA MÍNIMA GARANTIZADA
delitos_clean <- delitos_completo %>% 
  mutate(fecha_convertida = as.Date(fecha)) %>% 


# NO filtrar por fechas NA por ahora
                           
mutate(
      año = ifelse(!is.na(fecha_convertida), year(fecha_convertida), NA),
      mes = ifelse(!is.na(fecha_convertida), month(fecha_convertida), NA)
       )
                         
 # Verificar

cat("Registros en versión segura:", nrow(delitos_clean), "\n")

# Chequeo de valores faltantes o vacíos por columnas clave (parece que estan todos)

sapply(delitos_clean[, c("tipo", "subtipo", "barrio", "uso_moto",
                         "uso_arma", "cantidad", "id.mapa", "anio",
                         "mes", "dia", "fecha", "franja","comuna",
                         "latitud", "longitud", "fecha_convertida",
                         "año")],
       function(x) {
         c(faltantes = sum(is.na(x)),
           vacíos = sum(x == "", na.rm = TRUE))
       })

# Convierto a factor para facilitar gráficos posteriormente

delitos_clean <- delitos_clean %>%
  mutate(
    franja = as.factor(franja),
    tipo = as.factor(tipo),
    subtipo = as.factor(subtipo),
    uso_arma = as.factor(uso_arma),
    uso_moto = as.factor(uso_moto),
    barrio = as.factor(barrio),
    comuna = as.factor(comuna)
  )

write.csv(delitos_clean , "input/delitos_clean.csv", row.names = FALSE)