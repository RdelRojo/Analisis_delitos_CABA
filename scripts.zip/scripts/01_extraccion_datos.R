# === INFORMACIÓN DEL ESTUDIANTE ===
# Nombre y Apellido: Caterina Monges 
# Nombre y Apellido: Ramiro Otamendi
legajo <- 898967
legajo<- 913384
# Email:mongescaterina@gmail.com
# Email: rami.otamendi@gmail.com 

library(tidyverse)
library(lubridate) 
library(scales) 
library(dplyr)
library(ggplot2)
library(viridis)
library(plotly)
library(htmlwidgets)

instub <- 'Datos_trabajo'      #directorio donde guarde los csv
outstub <- 'resultados'

dir.create("raw")
dir.create("input")
dir.create("output")
dir.create("scripts")

# Cargar datos:

delitos_2019 <- read.csv("raw/delitos_2019.csv")
delitos_2020 <- read.csv("raw/delitos_2020.csv")
delitos_2021 <- read.csv("raw/delitos_2021.csv")
delitos_2022 <- read.csv("raw/delitos_2022.csv")
delitos_2023 <- read.csv("raw/delitos_2023.csv")


 #Combinacion de todas las bases 

delitos_completo <- rbind(delitos_2019, delitos_2020, delitos_2021,
                          delitos_2022, delitos_2023)
                         
write.csv(delitos_completo , "raw/delitos_completo.csv", row.names = FALSE) 
