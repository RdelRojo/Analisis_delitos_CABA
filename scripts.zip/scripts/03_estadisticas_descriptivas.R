
#-------------------------------------------------------------------------------
# 1: Tendencia general de delitos
#-------------------------------------------------------------------------------

# Cantidad de delitos agrupados por año (Gráfico Interactivo) 

delitos_por_anio <- delitos_clean %>%
  group_by(año) %>%
  summarise(total_delitos = n()) %>%
  arrange(año)
  
write.csv(delitos_por_anio , "output/delitos_por_anio.csv", row.names = FALSE)
  
#-------------------------------------------------------------------------------  
# 2: Delitos más frecuentes con los correspondientes subtipos
#-------------------------------------------------------------------------------

# Top 5 tipos más comunes (sin incluir Homicidios)

top_tipos <- delitos_clean %>%
  filter(tipo != "Homicidios") %>%
  count(tipo, sort = TRUE) %>%
  slice_max(n, n = 5) %>%
  pull(tipo)
  
# Top subtipos

top_subtipos <- delitos_clean %>%
  filter(tipo %in% top_tipos) %>%
  count(tipo, subtipo, sort = TRUE) %>%
  group_by(tipo) %>%
  slice_max(n, n = 5) %>%
  ungroup()
  
# Filtramos solo los homicidios y contamos subtipos

homicidios <- delitos_clean %>%
  filter(tipo == "Homicidios") %>%
  count(subtipo, sort = TRUE)
  
write.csv(top_tipos , "output/top_tipos.csv", row.names = FALSE)
write.csv(top_subtipos , "output/top_subtipos.csv", row.names = FALSE)
write.csv(homicidios , "output/homicidios.csv", row.names = FALSE)

#------------------------------------------------------------------------------  
# 3: ¿Donde ocurren los delitos?
#-------------------------------------------------------------------------------

#TOP 5 de barrios con mayor cantidad de delitos + tipo de Delito 

top_barrios <- delitos_clean %>%
  filter(!is.na(barrio) & barrio != "" & barrio != "No disponible") %>%
  count(barrio, sort = TRUE) %>%
  top_n(5) %>%
  mutate(
    porcentaje = n / sum(delitos_clean$barrio != "No disponible" & 
                           !is.na(delitos_clean$barrio), na.rm = TRUE) * 100,
    porcentaje_label = paste0(round(porcentaje, 1), "%")
  )
  
# Encontrar el delito más común por barrio (para los top 5)

delito_mas_comun_barrio <- delitos_clean %>%
  filter(!is.na(barrio) & barrio != "" & barrio != "No disponible" & 
           barrio %in% top_barrios$barrio) %>%
  count(barrio, tipo, sort = TRUE) %>%
  group_by(barrio) %>%
  slice_max(n, n = 1) %>%
  ungroup() %>%
  select(barrio, delito_principal = tipo, cantidad_delito_principal = n)
  
# Unir con el análisis principal

top_barrios <- top_barrios %>%
  left_join(delito_mas_comun_barrio, by = "barrio") %>%
  mutate(
    porcentaje_delito_principal = round(cantidad_delito_principal / n * 100, 1),
    etiqueta_completa = paste0(scales::comma(n), " (", porcentaje_label, ")\n",
                               "Delito principal: ", delito_principal, 
                               " (", porcentaje_delito_principal, "%)")
  )
  
# Bottom 5 barrios con menos delitos + delito más común por barrio

bottom_barrios <- delitos_clean %>%
  filter(!is.na(barrio) & barrio != "" & barrio != "No disponible") %>%
  count(barrio, sort = FALSE) %>%  # sort = FALSE para obtener los menores
  top_n(-5) %>%  # top_n con valor negativo para obtener los 5 menores
  mutate(
    porcentaje = n / sum(delitos_clean$barrio != "No disponible" & 
                           !is.na(delitos_clean$barrio), na.rm = TRUE) * 100,
    porcentaje_label = paste0(round(porcentaje, 2), "%")  
  )
  
# Encontrar el delito más común por barrio (para los bottom 5)

delito_mas_comun_bottom <- delitos_clean %>%
  filter(!is.na(barrio) & barrio != "" & barrio != "No disponible" & 
           barrio %in% bottom_barrios$barrio) %>%
  count(barrio, tipo, sort = TRUE) %>%
  group_by(barrio) %>%
  slice_max(n, n = 1) %>%
  ungroup() %>%
  select(barrio, delito_principal = tipo, cantidad_delito_principal = n)
  
# Unir con el análisis principal

bottom_barrios <- bottom_barrios %>%
  left_join(delito_mas_comun_bottom, by = "barrio") %>%
  mutate(
    porcentaje_delito_principal = round(cantidad_delito_principal / n * 100, 1),
    etiqueta_completa = paste0(scales::comma(n), " (", porcentaje_label, ")\n",
                               "Delito principal: ", delito_principal, 
                               " (", porcentaje_delito_principal, "%)")
  )

write.csv(top_barrios , "output/top_barrios.csv", row.names = FALSE)
write.csv(delito_mas_comun_barrios ,"output/delito_mas_comun_barrio.csv", row.names = FALSE)
write.csv(bottom_barrios , "output/bottom_barrios.csv", row.names = FALSE)
write.csv(delito_mas_comun_bottom , "output/delito_mas_comun_bottom.csv", row.names = FALSE)

#--------------------------------------------------------------------------------  
# 4: Frecuencia de delitos (delitos por hora y conclusiones)
#--------------------------------------------------------------------------------

# Tomamos el rango de tiempo del período completa 

fecha_inicio <- min(delitos_clean$fecha_convertida, na.rm = TRUE)
fecha_fin <- max(delitos_clean$fecha_convertida, na.rm = TRUE)

# Cantidad total de días, horas y delitos 

total_dias <- as.numeric(difftime(fecha_fin, fecha_inicio, units = "days"))
total_horas <- as.numeric(difftime(fecha_fin, fecha_inicio, units = "hours"))
total_delitos <- nrow(delitos_clean)

# Calulamos cantidad de delitos por día y por hora (promedios)

delitos_por_dia <- total_delitos / total_dias
delitos_por_hora <- total_delitos / total_horas

# Vemos los resultados tomando todo el periodo (los 5 años)

cat("Desde", format(fecha_inicio, "%d/%m/%Y"),
    "hasta", format(fecha_fin, "%d/%m/%Y"), "\n")
cat("Total de delitos:", total_delitos, "\n")
cat("Promedio por día:", round(delitos_por_dia, 2), "\n")
cat("Promedio por hora:", round(delitos_por_hora, 2), "\n")
cat("→ Se comete 1 delito cada",
    round((1 / delitos_por_hora) * 60, 2), "minutos\n")

# Calculamos con qué tanta frecuencia ocurren los delitos por año

frecuencia_anual <- delitos_clean %>%
  group_by(año) %>%
  summarise(
    total_delitos = n(),
    fecha_inicio = min(fecha_convertida, na.rm = TRUE),
    fecha_fin = max(fecha_convertida, na.rm = TRUE)
  ) %>%
  mutate(
    total_horas = as.numeric(difftime(fecha_fin, fecha_inicio, units = "hours")),
    delitos_por_hora = total_delitos / total_horas
  )  
  
write.csv(delitos_por_dia , "output/delitos_por_dia.csv", row.names = FALSE)
write.csv(delitos_por_hora , "output/delitos_por_hora.csv", row.names = FALSE)
write.csv(frecuencia_anual , "output/frecuencia_anual.csv", row.names = FALSE)